(function() {
  $('#delete').click(function() {
    var id;
    id = $(this).data('id');
    return alert(id);
  });

}).call(this);
